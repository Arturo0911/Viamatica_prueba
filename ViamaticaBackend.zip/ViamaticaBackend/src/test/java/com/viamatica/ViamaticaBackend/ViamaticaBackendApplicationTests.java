package com.viamatica.ViamaticaBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViamaticaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
